import React from 'react' ;
// 6.9k (gzipped: 2.7k)

export default function UpdateBanners(){

    return(
        <div>
           <h2>Banners</h2> 
        </div>
    )
}