import React from 'react' ;
// 6.9k (gzipped: 2.7k)

export default function UpdateTraining(){

    return(
        <div>
           <h2>Update Coummunity</h2> 
        </div>
    )
}