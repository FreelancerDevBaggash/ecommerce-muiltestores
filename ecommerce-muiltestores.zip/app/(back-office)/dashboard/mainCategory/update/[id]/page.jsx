import React from 'react' ;
// 6.9k (gzipped: 2.7k)

export default function UpdateMainCategory(){

    return(
        <div>
           <h2>Update MainCategory</h2> 
        </div>
    )
}