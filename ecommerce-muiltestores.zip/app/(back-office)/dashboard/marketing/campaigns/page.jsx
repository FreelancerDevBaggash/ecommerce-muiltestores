"use client"

const CampaignsPage = () => {
  return <div>Campaigns Page Content</div>
}

export default CampaignsPage
