import React from 'react'
import Pricing from '../../../components/Pricing'
export default function page() {
  return (
    <div>
      <Pricing/>
    </div>
  )
}
