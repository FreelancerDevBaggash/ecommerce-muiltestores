import React from 'react'

export default function UserDashboard() {
  return (
    <div>
      <h2>Welcome User</h2>
    </div>
  )
}
