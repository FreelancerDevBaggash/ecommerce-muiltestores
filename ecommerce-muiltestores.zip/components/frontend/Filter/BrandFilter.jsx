import React from 'react'

export default function BrandFilter() {
    return (
        <div>
            <h2>Brand Filter </h2>
        </div>
    );
}

